﻿@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ============================================
echo SmartExam 4.2 后端启动器（Python 3.14）
echo ============================================

REM 1. 检查 Python 3.14
py -3.14 --version >nul 2>&1
if errorlevel 1 (
  echo [错误] 未检测到 Python 3.14。
  echo 请确认已安装 Python 3.14，并在安装时勾选 Add Python to PATH。
  pause
  exit /b 1
)
py -3.14 --version

REM 2. 创建项目专用虚拟环境（不存在时自动创建）
if not exist ".venv\Scripts\python.exe" (
  echo [1/3] 正在创建 Python 3.14 虚拟环境...
  py -3.14 -m venv .venv
  if errorlevel 1 (
    echo [错误] 虚拟环境创建失败。
    pause
    exit /b 1
  )
) else (
  echo [1/3] 检测到已有 .venv，直接使用。
)

REM 3. 首次启动时安装依赖；已经安装则跳过
.venv\Scripts\python.exe -c "import fastapi,uvicorn,pydantic,multipart" >nul 2>&1
if errorlevel 1 (
  echo [2/3] 正在安装后端依赖，请耐心等待...
  .venv\Scripts\python.exe -m pip install --upgrade pip
  .venv\Scripts\python.exe -m pip install -r requirements.txt
  if errorlevel 1 (
    echo [错误] 依赖安装失败。
    pause
    exit /b 1
  )
) else (
  echo [2/3] 后端依赖已安装，跳过安装。
)

echo [3/3] 正在启动 FastAPI...
echo 接口文档：http://127.0.0.1:8000/docs
echo 健康检查：http://127.0.0.1:8000/api/health
echo 关闭后端请按 Ctrl+C。
echo.
.venv\Scripts\python.exe -m uvicorn main:app --reload --host 127.0.0.1 --port 8000
pause
