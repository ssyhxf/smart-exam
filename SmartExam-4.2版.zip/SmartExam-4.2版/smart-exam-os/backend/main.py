from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List

app = FastAPI(title="SmartExam 4.2 Grading API", version="0.2.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class RubricItem(BaseModel):
    key: str
    score: float

class TextGradingRequest(BaseModel):
    question: str
    answer: str
    rubric: List[RubricItem]

class CommentRequest(BaseModel):
    comment: str

SCORES = [
    {"sid": "2023213048", "name": "张明远", "cls": "计算机 2301", "obj": 42, "subj": 38, "total": 80, "rank": 12, "status": "已发布"},
    {"sid": "2023213049", "name": "李思远", "cls": "计算机 2301", "obj": 45, "subj": 44, "total": 89, "rank": 3, "status": "已发布"},
    {"sid": "2023213056", "name": "刘子豪", "cls": "计算机 2301", "obj": 38, "subj": 33, "total": 71, "rank": 38, "status": "已发布"},
    {"sid": "2023213067", "name": "王一诺", "cls": "计算机 2302", "obj": 40, "subj": 41, "total": 81, "rank": 9, "status": "已发布"},
    {"sid": "2023213088", "name": "陈嘉豪", "cls": "计算机 2302", "obj": 36, "subj": 36, "total": 72, "rank": 34, "status": "已发布"},
    {"sid": "2023213091", "name": "赵子豪", "cls": "计算机 2302", "obj": 44, "subj": 39, "total": 83, "rank": 7, "status": "已发布"},
    {"sid": "2023213102", "name": "周子墨", "cls": "网络 2301", "obj": 34, "subj": 31, "total": 65, "rank": 52, "status": "已发布"},
    {"sid": "2023213112", "name": "王雨桐", "cls": "计算机 2303", "obj": 43, "subj": 42, "total": 85, "rank": 5, "status": "已发布"},
    {"sid": "2023213148", "name": "李文博", "cls": "计算机 2301", "obj": 39, "subj": 40, "total": 79, "rank": 14, "status": "已发布"},
    {"sid": "2023213160", "name": "孙嘉怡", "cls": "计算机 2302", "obj": 37, "subj": 35, "total": 72, "rank": 34, "status": "已发布"},
    {"sid": "2023213186", "name": "吴雅婷", "cls": "网络 2301", "obj": 41, "subj": 37, "total": 78, "rank": 16, "status": "已发布"},
    {"sid": "2023213194", "name": "郑浩然", "cls": "物理 2301", "obj": 35, "subj": 36, "total": 71, "rank": 38, "status": "已发布"},
]

PORTRAITS = {
    "2023213048": {
        "name": "张明远", "sid": "2023213048", "cls": "计算机 2301", "grade": "B+", "matchRate": 88.6, "dims": 52,
        "radar": [{"axis":"理论知识","v":82},{"axis":"实践操作","v":65},{"axis":"逻辑推理","v":74},{"axis":"问题解决","v":58},{"axis":"专业技能","v":70}],
        "mastery": [{"kp":"面向对象基础","v":92},{"kp":"集合框架","v":86},{"kp":"异常处理","v":78},{"kp":"多线程","v":64},{"kp":"IO 流","v":61},{"kp":"JVM 内存模型","v":47},{"kp":"泛型与反射","v":42},{"kp":"网络编程","v":35}],
        "weakness": [{"kp":"网络编程","desc":"TCP/UDP 编程模型混淆，三次握手流程描述不完整","rate":35},{"kp":"泛型与反射","desc":"通配符边界理解偏差，反射应用场景不清晰","rate":42},{"kp":"JVM 内存模型","desc":"堆栈分区易混淆，垃圾回收机制掌握薄弱","rate":47}],
        "suggestions": ["优先补强「网络编程」：推荐 3 个 TCP 实战案例 + Socket 编程专项练习（预计 2.5 小时）","「泛型与反射」建议结合源码阅读巩固，已生成 12 道针对性练习题","「JVM 内存模型」可先完成微课《一文看懂 JVM 分区》，再做知识图谱路径测验"],
        "badges": ["集合框架 · 精通","面向对象 · 扎实","多线程 · 良好"],
        "comment": "张明远同学对面向对象与集合框架掌握扎实，逻辑推理能力良好；但网络编程与 JVM 底层原理存在明显短板，建议按推送路径集中补强后参加复测。"
    },
    "2023213056": {
        "name":"刘子豪","sid":"2023213056","cls":"计算机 2301","grade":"B", "matchRate":90.1,"dims":52,
        "radar":[{"axis":"理论知识","v":76},{"axis":"实践操作","v":72},{"axis":"逻辑推理","v":70},{"axis":"问题解决","v":66},{"axis":"专业技能","v":74}],
        "mastery":[{"kp":"面向对象基础","v":84},{"kp":"集合框架","v":79},{"kp":"异常处理","v":71},{"kp":"多线程","v":69},{"kp":"IO 流","v":73},{"kp":"JVM 内存模型","v":55},{"kp":"泛型与反射","v":58},{"kp":"网络编程","v":62}],
        "weakness":[{"kp":"JVM 内存模型","desc":"对对象创建、栈帧与垃圾回收触发条件理解不完整","rate":55},{"kp":"泛型与反射","desc":"通配符与类型擦除概念存在混淆","rate":58},{"kp":"网络编程","desc":"异常处理与Socket编程边界掌握不足","rate":62}],
        "suggestions":["完成 JVM 内存区与GC 专项微课并进行 8 题巩固","围绕泛型边界与类型擦除完成 6 道代码题","增加 1 次 Socket 综合实操，验证理论迁移能力"],
        "badges":["集合框架 · 良好","实践操作 · 良好","IO 流 · 扎实"],
        "comment":"刘子豪具备较好的编程基础和实践操作能力，当前主要需要加强 JVM、泛型与网络编程的系统性理解。"
    },
    "2023213067": {
        "name":"王一诺","sid":"2023213067","cls":"计算机 2302","grade":"B+", "matchRate":91.4,"dims":52,
        "radar":[{"axis":"理论知识","v":84},{"axis":"实践操作","v":70},{"axis":"逻辑推理","v":80},{"axis":"问题解决","v":75},{"axis":"专业技能","v":72}],
        "mastery":[{"kp":"面向对象基础","v":93},{"kp":"集合框架","v":89},{"kp":"异常处理","v":82},{"kp":"多线程","v":72},{"kp":"IO 流","v":67},{"kp":"JVM 内存模型","v":63},{"kp":"泛型与反射","v":60},{"kp":"网络编程","v":72}],
        "weakness":[{"kp":"泛型与反射","desc":"高级反射API使用熟练度仍可提高","rate":60},{"kp":"IO 流","desc":"缓冲与字符流场景区分不够稳定","rate":67},{"kp":"JVM 内存模型","desc":"GC策略差异的应用判断需要加强","rate":63}],
        "suggestions":["完成反射API 小项目，形成接口到实现类的完整调用链","补做IO流场景判断题与编程题","通过GC案例题强化JVM知识迁移"],
        "badges":["逻辑推理 · 优良","集合框架 · 精通","网络编程 · 良好"],
        "comment":"王一诺在理论知识和逻辑推理方面表现稳定，当前训练重点集中在高级API、IO与JVM知识迁移。"
    },
    "2023213088": {
        "name":"陈嘉豪","sid":"2023213088","cls":"计算机 2302","grade":"B", "matchRate":87.9,"dims":50,
        "radar":[{"axis":"理论知识","v":68},{"axis":"实践操作","v":64},{"axis":"逻辑推理","v":61},{"axis":"问题解决","v":58},{"axis":"专业技能","v":66}],
        "mastery":[{"kp":"面向对象基础","v":74},{"kp":"集合框架","v":70},{"kp":"异常处理","v":65},{"kp":"多线程","v":53},{"kp":"IO 流","v":60},{"kp":"JVM 内存模型","v":49},{"kp":"泛型与反射","v":45},{"kp":"网络编程","v":51}],
        "weakness":[{"kp":"泛型与反射","desc":"泛型边界与反射调用过程掌握不牢","rate":45},{"kp":"JVM 内存模型","desc":"堆、栈与方法区概念容易混淆","rate":49},{"kp":"网络编程","desc":"TCP流程与异常场景理解不足","rate":51}],
        "suggestions":["先完成 Java 泛型基础微课，再做 10 道边界判断题","通过 JVM 图解课程重新建立内存模型概念","用 Socket 小项目巩固TCP流程与异常处理"],
        "badges":["面向对象 · 良好","实践操作 · 合格","集合框架 · 良好"],
        "comment":"陈嘉豪已有一定 Java 基础，当前需要通过结构化复习与小项目练习提升底层知识和综合问题解决能力。"
    },
}

SCORES_PUBLISHED = True

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "grading", "version": "0.2.0"}

@app.get("/api/scores")
def get_scores():
    totals = [r["total"] for r in SCORES]
    avg = sum(totals) / len(totals)
    max_score = max(totals)
    min_score = min(totals)
    pass_rate = sum(1 for x in totals if x >= 54) / len(totals) * 100
    mean = avg
    variance = sum((x - mean) ** 2 for x in totals) / len(totals)
    return {"examName":"Java 程序设计阶段测验","rows":SCORES,"stats":{"avg":round(avg,1),"max":max_score,"min":min_score,"passRate":round(pass_rate,1),"std":round(variance ** 0.5,1),"discrimination":"0.41"},"published":SCORES_PUBLISHED}

@app.post("/api/scores/publish")
def publish_scores():
    global SCORES_PUBLISHED
    SCORES_PUBLISHED = True
    for r in SCORES:
        r["status"] = "已发布"
    return {"ok": True, "count": len(SCORES), "published": True}

@app.get("/api/scores/{sid}")
def get_score_detail(sid: str):
    for r in SCORES:
        if r["sid"] == sid:
            return {"ok": True, "data": r, "components":{"客观题":r["obj"],"主观题":r["subj"]}}
    return {"ok": False, "message": "学生不存在"}

@app.get("/api/scores/analysis/summary")
def score_analysis():
    totals = [r["total"] for r in SCORES]
    avg = sum(totals) / len(totals)
    return {"sampleCount":len(totals),"average":round(avg,1),"passRate":round(sum(1 for x in totals if x>=54)/len(totals)*100,1),"max":max(totals),"focus":["主观题得分差异","知识点覆盖率","薄弱能力维度"]}

@app.get("/api/portraits/{sid}")
def get_portrait(sid: str):
    return PORTRAITS.get(sid, PORTRAITS["2023213048"])

@app.post("/api/portraits/{sid}/study-plan")
def study_plan(sid: str):
    p = PORTRAITS.get(sid, PORTRAITS["2023213048"])
    plan = []
    for i, text in enumerate(p["suggestions"], start=1):
        plan.append({"title": f"阶段 {i}：针对性训练", "detail": text})
    return {"sid": sid, "estimateHours": 4.0, "plan": plan}

@app.post("/api/portraits/{sid}/comment")
def save_comment(sid: str, req: CommentRequest):
    p = PORTRAITS.get(sid)
    if not p:
        p = PORTRAITS["2023213048"].copy()
        p["sid"] = sid
        PORTRAITS[sid] = p
    p["comment"] = req.comment
    return {"ok": True, "sid": sid, "comment": p["comment"]}

@app.post("/api/grading/text")
def grade_text(req: TextGradingRequest):
    answer = req.answer.strip().lower()
    total = sum(x.score for x in req.rubric) or 1
    hit = 0.0
    details = []
    for item in req.rubric:
        synonyms = {
            "底层结构": ["哈希表", "红黑树", "hashmap", "treemap"],
            "复杂度": ["o(", "log n", "o(1)"],
            "线程安全": ["线程安全", "synchronized", "并发"],
            "适用场景": ["有序", "排序", "范围查询", "范围查找"],
        }.get(item.key, [item.key.lower()])
        matched = any(s in answer for s in synonyms)
        if matched:
            hit += item.score
        details.append({"key": item.key, "score": item.score if matched else 0, "max_score": item.score, "matched": matched})
    score = min(total, hit + (1 if len(answer) > 80 and hit < total else 0))
    coverage = score / total
    confidence = min(0.98, 0.70 + 0.25 * coverage + (0.03 if len(answer) > 80 else 0))
    return {"score": round(score,2),"max_score": total,"confidence":round(confidence,2),"details":details,"knowledge_points":["Map数据结构","集合框架","复杂度分析"],"diagnosis":"主要评分点已覆盖" if coverage>=0.85 else "存在评分点缺失，建议复核","evidence":["学生答案原文由接口保留，可继续扩展片段级证据"]}

@app.post("/api/grading/audio")
async def grade_audio(file: UploadFile = File(...)):
    content = await file.read()
    return {"filename":file.filename,"size":len(content),"score":89,"confidence":0.91,"summary":"音频已接收。当前为基线 Demo；接入 ASR 后可生成真实转写、语速、停顿及内容评分。","details":["发音准确度 88","语流流畅度 90","内容完整度 91","逻辑性 87"]}

@app.post("/api/grading/video")
async def grade_video(file: UploadFile = File(...)):
    content = await file.read()
    return {"filename":file.filename,"size":len(content),"score":86,"confidence":0.84,"summary":"视频已接收。当前为基线 Demo；接入 FFmpeg/OpenCV/YOLO/OCR/VLM 后可输出真实操作时间轴。","details":["00:05 设备准备 ✓","00:13 参数设置 ✓","00:21 正确操作 ✓","00:34 读取结果 ✓","00:42 完成记录 ⚠"]}
