# SmartExam OS 4.2 后端｜Python 3.14 兼容版

本后端使用 FastAPI，为 4.2“智能评阅与能力诊断”提供接口，并承接成绩管理、能力画像的数据服务。

## Python 版本

推荐并固定使用 **Python 3.14**。本版本将 Pydantic 升级到 2.13.5，并将 FastAPI 更新到 0.131.0，避免旧版 Pydantic Core 在 Python 3.14 Windows 环境下触发源码构建问题。

## 最简单的启动方式

双击本目录的：

`启动后端.bat`

脚本会自动：
1. 检查 Python 3.14；
2. 不存在时创建 `.venv`；
3. 首次启动安装 `requirements.txt`；
4. 启动 `http://127.0.0.1:8000`。

## 手动启动

```powershell
cd smart-exam-os\backend
py -3.14 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

## 接口

- `GET /api/health`：服务状态
- `POST /api/grading/text`：文本主观题基线评分
- `POST /api/grading/audio`：音频上传与基线评价
- `POST /api/grading/video`：视频上传与基线评价
- `GET /api/scores`：成绩管理数据
- `POST /api/scores/publish`：发布成绩
- `GET /api/scores/{sid}`：单名学生成绩详情
- `GET /api/scores/analysis/summary`：学情统计摘要
- `GET /api/portraits/{sid}`：学生能力画像
- `POST /api/portraits/{sid}/study-plan`：生成学习计划
- `POST /api/portraits/{sid}/comment`：保存教师修订评语

## 浏览器测试

API 文档：`http://127.0.0.1:8000/docs`

健康检查：`http://127.0.0.1:8000/api/health`

## 前后端同时运行

前端：`http://127.0.0.1:5500`
后端：`http://127.0.0.1:8000`

前端通过 `fetch()` 调用后端接口；项目已经配置 CORS，适合本地演示。

## 当前实现边界

当前后端使用内存演示数据，重启后会恢复。文本评分是“评分点 + 规则”的基线版本；音频和视频接口提供文件接收骨架。正式比赛版本可继续接入真实 LLM、Embedding、ASR、CV/VLM、OCR 和 Neo4j。
