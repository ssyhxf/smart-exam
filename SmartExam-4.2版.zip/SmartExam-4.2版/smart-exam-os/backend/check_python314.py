import sys

major, minor = sys.version_info[:2]
if (major, minor) != (3, 14):
    raise SystemExit(f"需要 Python 3.14，当前为 Python {major}.{minor}")
print(f"Python 版本正确：{sys.version.split()[0]}")
print(f"解释器：{sys.executable}")
