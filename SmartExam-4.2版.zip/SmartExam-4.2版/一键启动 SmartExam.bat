﻿@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo 正在启动 SmartExam 4.2 前后端...
start "SmartExam 后端" "%~dp0smart-exam-os\backend\启动后端.bat"
timeout /t 2 /nobreak >nul
start "SmartExam 前端" cmd /k py -3.14 -m http.server 5500 --bind 127.0.0.1 --directory "%~dp0smart-exam-os"
timeout /t 2 /nobreak >nul
start "SmartExam Browser" http://127.0.0.1:5500
exit /b 0
