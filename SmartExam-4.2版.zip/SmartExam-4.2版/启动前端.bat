﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ============================================
echo SmartExam 4.2 前端启动器
echo ============================================
py -3.14 --version >nul 2>&1
if errorlevel 1 (
  echo [错误] 未检测到 Python 3.14。
  pause
  exit /b 1
)
echo 前端地址：http://127.0.0.1:5500
start "SmartExam Browser" http://127.0.0.1:5500
py -3.14 -m http.server 5500 --bind 127.0.0.1 --directory "%~dp0smart-exam-os"
pause
